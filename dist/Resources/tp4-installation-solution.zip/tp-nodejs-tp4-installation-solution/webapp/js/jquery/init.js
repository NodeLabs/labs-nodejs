$(document).ready(function(){
    $('.parallax').parallax();
});

$(document).ready(function() {
    $('select').material_select();
    $(".button-collapse").sideNav();
});

