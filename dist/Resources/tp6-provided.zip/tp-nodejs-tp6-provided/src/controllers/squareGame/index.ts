
import SquareGameCtrl from "./SquareGameCtrl";
import SquareGameWS from "./SquareGameWS";

export {
    SquareGameCtrl,
    SquareGameWS
};