declare interface ICard {
    label: string;
    description?: string;
    href: string;
    picture?: string;
    btn?: string;
}