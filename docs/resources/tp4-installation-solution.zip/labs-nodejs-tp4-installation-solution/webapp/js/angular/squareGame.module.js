angular
    .module('squareGame', []);