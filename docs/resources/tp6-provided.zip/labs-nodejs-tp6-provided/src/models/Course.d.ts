declare interface ICourse extends ICard{
    value: string;
}